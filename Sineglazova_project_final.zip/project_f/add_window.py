import sys
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication, QWidget, QMainWindow, QPushButton, QLineEdit,
    QLabel, QGridLayout, QFileDialog, QRadioButton, QMessageBox,
    QSpinBox
)
from PyQt6.QtGui import QIcon, QImage, QPixmap
from PyQt6.QtCore import Qt, QSize
import os
import pandas as pd
import books_list
from books_list import books_add
import main_window

books_counter = 0
class AnotherWindow(QWidget):
    """
    This "window" is a QWidget. If it has no parent, it
    will appear as a free-floating window as we want.
    """
    def __init__(self):
        super().__init__()
        layout = QGridLayout()
        self.resize(500, 500)
        #layout.setContentsMargins(20, 20, 20, 20)
        #layout.setSpacing(10)
        self.setWindowTitle('Adding New Bookie')
        self.setWindowIcon(QIcon('an_w_icon.jpg'))
        self.setLayout(layout)
        
        self.title = QLabel("‧₊˚✧[Let's add new book!]✧˚₊‧")
        self.title.setStyleSheet('font-size: 20px; font-family: Georgia')
        layout.addWidget(self.title, 0, 0, 1, 5, Qt.AlignmentFlag.AlignCenter)
        
        # Виджет для отображения картинки
        self.cover_label = QLabel(self)
        layout.addWidget(self.cover_label, 1, 0, 4, 2, Qt.AlignmentFlag.AlignCenter)
        
        # Виджет для кнопки "Выбрать обложку"
        self.cover_button = QPushButton('Choose Cover', self)
        self.cover_button.setStyleSheet('font-size: 14px; font-family: Georgia')
        layout.addWidget(self.cover_button, 5, 0, 1, 2, Qt.AlignmentFlag.AlignCenter)
        
        self.cover_button.clicked.connect(self.upload_cover)
        
        self.author_label = QLabel('Author:')
        self.author_label.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.author_label, 1, 2)
        
        self.author_input = QLineEdit()
        self.author_input.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.author_input, 1, 3, 1, 2)
        
        self.title_label = QLabel('Title:')
        self.title_label.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.title_label, 2, 2)
        
        self.title_input = QLineEdit()
        self.title_input.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.title_input, 2, 3, 1, 2)
        
        self.pages_label = QLabel('Pages:')
        self.pages_label.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.pages_label, 3, 2)
        
        self.pages_input = QLineEdit()
        self.pages_input.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.pages_input, 3, 3, 1, 2)
        
        self.status_radio_read = QRadioButton()
        self.status_radio_read.setText('Read')
        self.status_radio_read.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.status_radio_read, 4, 2)
        
        self.status_radio_reading = QRadioButton()
        self.status_radio_reading.setText('Reading')
        self.status_radio_reading.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.status_radio_reading, 4, 3)
        
        self.status_radio_aband = QRadioButton()
        self.status_radio_aband.setText('Abandoned')
        self.status_radio_aband.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.status_radio_aband, 5, 2)
        
        self.status_radio_plan = QRadioButton()
        self.status_radio_plan.setText('Planned')
        self.status_radio_plan.setStyleSheet('font-size: 18px; font-family: Georgia')
        layout.addWidget(self.status_radio_plan, 5, 3)
        
        self.save_button = QPushButton('SAVE', self)
        self.save_button.setStyleSheet('font-size: 14px; font-family: Georgia')
        layout.addWidget(self.save_button, 6, 0, 1, 2, Qt.AlignmentFlag.AlignCenter)
        self.save_button.clicked.connect(self.save_book)
        
        self.cancel_button = QPushButton('CANCEL', self)
        self.cancel_button.setStyleSheet('font-size: 14px; font-family: Georgia')
        layout.addWidget(self.cancel_button, 6, 3, Qt.AlignmentFlag.AlignCenter)
        self.cancel_button.clicked.connect(self.cancel_adding)
        
    
    # Метод для загрузки изображения    
    def upload_cover(self):
        # Открытие диалога для выбора файла
        file_dialog = QFileDialog(self)
        file_dialog.setNameFilter('Images (*.png *.jpg *.jpeg *.bmp)')
        if file_dialog.exec():
            # Загрузка и изменение размера изображения
            image_path = file_dialog.selectedFiles()[0]
            image = QImage(image_path)
            image = image.scaled(QSize(300, 300), Qt.AspectRatioMode.KeepAspectRatio)
            new_image_path = "image_{}.jpg".format(len(os.listdir(".")) + 1)
            #image.save(new_image_path, 'PNG', quality=95)
            pixmap = QPixmap.fromImage(image)
            self.cover_label.setPixmap(pixmap)
        self.new_image_path = new_image_path
        self.image = image
            
        
    
    # Метод для сохранения информации о добавленной книге
    # и сохранения обложки в папку проекта
    def save_book(self):
        global books_counter
        books_counter += 1
        print(f'Books: {books_counter}')
        self.image.save(self.new_image_path, 'PNG', quality=100)
        
        cover = self.new_image_path
        author = self.author_input.text()
        title = self.title_input.text()
        pages = self.pages_input.text()
        status_read = self.status_radio_read.isChecked()
        status_reading = self.status_radio_reading.isChecked()
        status_aband = self.status_radio_aband.isChecked()
        status_plan = self.status_radio_plan.isChecked()
        

        books_list.books_add([cover, author,title,pages,status_read,status_reading,status_aband,status_plan])
        
        
        self.book_str = f"Added book: Cover File Path: {cover}  - Author: {author} - Title: {title} - Pages: {pages} - Read: {status_read} - Reading: {status_reading} - Abandoned: {status_aband} - Planned: {status_plan}"
        
        message = QMessageBox()
        message.setWindowIcon(QIcon('an_w_icon.jpg'))
        message.setWindowTitle('Adding New Bookie')
        message.setText('YOUR BOOK IS ADDED!^^')
        message.setStyleSheet('font-size: 20px; font-family: Georgia')
        message.exec()
        
        self.close()
        
    
    def cancel_adding(self):
        print('Adding a book is cancelled!')
        
        message = QMessageBox()
        message.setWindowIcon(QIcon('book_4.jpg'))
        message.setWindowTitle('Adding New Bookie')
        message.setText('ADDING NEW BOOK IS CANCELLED!')
        message.setStyleSheet('font-size: 20px; font-family: Georgia')
        message.exec()
        
        #main_window.on_decrease() #not correct
        self.close()

    
    def show_window(self):
        self.show()