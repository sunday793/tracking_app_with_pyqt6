from add_window import *
#df_el = books_list.books_add()
books_covers = [['image_10.jpg'], ['image_11.jpg'], ['image_12.jpg']]
df1 = pd.DataFrame(books_covers, columns = ['Cover'])
#from books_list import df1

class MainWindow(QMainWindow):
    
    window_counter = 0

    def __init__(self):
        super().__init__()
        """25.07 вечер
        
        """
        self.window_counter = 0
        self.array_log_books_btn = []
        
        layout = QGridLayout()
        self.resize(600, 600)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)
        self.setWindowTitle('My Bookies')
        self.setWindowIcon(QIcon('app_icon.jpg'))
        self.w = None  # No external window yet.
        
        self.title = QLabel('‧₊˚✧[Welcome back, reader!]✧˚₊‧')
        self.title.setStyleSheet('font-size: 20px; font-family: Georgia')
        layout.addWidget(self.title, 0, 0, 1, 3, Qt.AlignmentFlag.AlignCenter)
        
        self.books_count_label = QLabel()
        layout.addWidget(self.books_count_label, 1, 1, Qt.AlignmentFlag.AlignCenter)
        font = self.books_count_label.font()
        font.setPointSizeF(18)
        self.books_count_label.setFont(font)
        

        #МОЙ МАЗОХИЗМ
        self.btn_cover1 = QPushButton(parent=self)
        self.btn_cover1.clicked.connect(self.click_to_show_w)
        layout.addWidget(self.btn_cover1, 2, 0, 2, 1, Qt.AlignmentFlag.AlignCenter)
        
        self.btn_cover2 = QPushButton(parent=self)
        self.btn_cover2.clicked.connect(self.click_to_show_w)
        layout.addWidget(self.btn_cover2, 2, 1, 2, 1, Qt.AlignmentFlag.AlignCenter)
        
        self.btn_cover3 = QPushButton(parent=self)
        self.btn_cover3.clicked.connect(self.click_to_show_w)
        layout.addWidget(self.btn_cover3, 2, 2, 2, 1, Qt.AlignmentFlag.AlignCenter)
        
        self.btn_add_book = QPushButton('Add Book', self)
        self.btn_add_book.setStyleSheet('font-size: 14px; font-family: Georgia')
        self.btn_add_book.clicked.connect(self.show_n_w_and_book_count)
        layout.addWidget(self.btn_add_book, 6, 0, Qt.AlignmentFlag.AlignCenter)
        
        self.btn_update_m_w = QPushButton('Update Window')
        self.btn_update_m_w.setStyleSheet('font-size: 14px; font-family: Georgia')
        self.btn_update_m_w.clicked.connect(self.update_main_window)
        layout.addWidget(self.btn_update_m_w, 6, 2, Qt.AlignmentFlag.AlignCenter)
        
        
        self._update_states()
        
        
        {'self.w1': 'self.btn_cover_1', 'self.w1': 'self.btn_cover_2',
     'self.w3': 'self.btn_cover_3'
        }
    
        self.buttons_covers = [self.btn_cover1, self.btn_cover2, self.btn_cover3]
        self.windows = []
        
        widget = QWidget()
        widget.setLayout(layout)
        self.setCentralWidget(widget)   
    
    
    def show_n_w_and_book_count(self):
        self.show_new_window()
        self._on_add()
        
        
    def _on_add(self):
        self.window_counter += 1
        self._update_states()
        
    def on_decrease(self):
        self.window_counter -= 1
        self._update_states()
    
    def _update_states(self):
        self.books_count_label.setNum(self.window_counter)
    
    def show_new_window(self): 
        
        if self.window_counter == 0:
            if self.window_counter == 0:
                #self.w1 = AnotherWindow()
                #self.array_log_books_btn.append(self.w)
                #self.windows.append(self.w1)
                self.windows.append(AnotherWindow())
                print(self.windows)
                print(f'Windows: {self.window_counter}')
                #self.w1.show()
                self.windows[self.window_counter].show()
            else:
                #self.w1.close()  # Close window.
                self.windows[self.window_counter].close()
                self.window_counter -= 1
                print(self.window_counter)
                #self.w1 = None  # Discard reference.
                self.windows[self.window_counter] = None
        elif self.window_counter == 1:
            if self.window_counter == 1:
                #self.w2 = AnotherWindow()
                #self.array_log_books_btn.append(self.w)
                #self.windows.append(self.w2)
                self.windows.append(AnotherWindow())
                print(self.windows)
                print(self.window_counter)
                #self.w2.show()
                self.windows[self.window_counter].show()
            else:
                #self.w2.close()  # Close window.
                self.windows[self.window_counter].close()
                self.window_counter -= 1
                print(self.window_counter)
                #self.w2 = None  # Discard reference.
                self.windows[self.window_counter] = None
        elif self.window_counter == 2:
            if self.window_counter == 2:
                #self.w2 = AnotherWindow()
                #self.array_log_books_btn.append(self.w)
                #self.windows.append(self.w2)
                self.windows.append(AnotherWindow())
                print(self.windows)
                print(self.window_counter)
                #self.w2.show()
                self.windows[self.window_counter].show()
            else:
                #self.w3.close()  # Close window.
                self.windows[self.window_counter].close()
                self.window_counter -= 1
                print(self.window_counter)
                #self.w3 = None  # Discard reference.
                self.windows[self.window_counter] = None

        
    def click_to_show_w(self):
        #test1 = self.btn_cover1.isEnabled()
        if self.btn_cover1.isEnabled() == True:
            #self.w1.show()
            self.windows[0].show()
        elif self.btn_cover2.isEnabled == True:
            self.windows[1].show()
        elif self.btn_cover3.isEnabled == True:
            self.windows[2].show()
        
    
    def update_main_window(self):
        self.update()
        self.show_cover()
        


    def show_cover(self):
        #df_el = books_list.books_add()
        image_name = df1.iloc[0]['Cover']
        image_path = os.path.join(os.path.dirname(__file__), image_name)
        pixmap = QPixmap(image_path)
        self.buttons_covers[0].setIcon(QIcon(pixmap))
        self.buttons_covers[0].setIconSize(QSize(300, 300))
        
        image_name = df1.iloc[1]['Cover']
        image_path = os.path.join(os.path.dirname(__file__), image_name)
        pixmap = QPixmap(image_path)
        self.buttons_covers[1].setIcon(QIcon(pixmap))
        self.buttons_covers[1].setIconSize(QSize(300, 300))
        
        image_name = df1.iloc[2]['Cover']
        image_path = os.path.join(os.path.dirname(__file__), image_name)
        pixmap = QPixmap(image_path)
        self.buttons_covers[2].setIcon(QIcon(pixmap))
        self.buttons_covers[2].setIconSize(QSize(300, 300))