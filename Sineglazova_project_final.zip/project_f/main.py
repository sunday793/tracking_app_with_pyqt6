if __name__=="__main__":
    from main_window import*

    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    app.exec()