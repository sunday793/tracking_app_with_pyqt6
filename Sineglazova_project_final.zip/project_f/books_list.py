import pandas as pd
books = []
def books_add(l=None):
    
    books.append(l)
    df1 = pd.DataFrame(books, columns = ['Cover', 'Author', 'Title', 'Pages', 'Read', 'Reading', 'Aband', 'Plan'])
    print(df1)
    df1.to_csv('books.csv', mode='a', index=False, header=False)
    #df1.to_csv('books.csv', mode='a')
    return df1
 
   